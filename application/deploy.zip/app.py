# app.py
import builtins
import logging
import pickle
import json
import os
import sys

# Fix Windows encoding issue with Unicode characters (emojis, IPA symbols, etc.)
# Must be done before any print statements that might contain Unicode
if sys.platform == 'win32':
    try:
        # Reconfigure stdout and stderr to use UTF-8 encoding
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        # Python < 3.7 doesn't have reconfigure, try alternative
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
        sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

import app_settings_cache
from config import *
from semantic_kernel import Kernel
from semantic_kernel_loader import initialize_semantic_kernel

#from azure.monitor.opentelemetry import configure_azure_monitor

from functions_authentication import *
from functions_content import *
from functions_documents import *
from functions_search import *
from functions_settings import *
from functions_appinsights import *
from functions_activity_logging import *

import threading
import time
from datetime import datetime

from route_frontend_authentication import *
from route_frontend_profile import *
from route_frontend_admin_settings import *
from route_frontend_control_center import *
from route_frontend_workspace import *
from route_frontend_chats import *
from route_frontend_conversations import *
from route_frontend_groups import *
from route_frontend_group_workspaces import *
from route_frontend_public_workspaces import *
from route_frontend_safety import *
from route_frontend_feedback import *
from route_frontend_support import *
from route_frontend_notifications import *

from route_backend_chats import *
from route_backend_search import *
from route_backend_conversations import *
from route_backend_documents import *
from route_backend_groups import *
from route_backend_users import *
from route_backend_group_documents import *
from route_backend_models import *
from route_backend_workflows import *
from route_backend_safety import *
from route_backend_feedback import *
from route_backend_settings import *
from route_backend_prompts import *
from route_backend_group_prompts import *
from route_backend_control_center import *
from route_backend_notifications import *
from route_backend_retention_policy import *
from route_backend_plugins import bpap as admin_plugins_bp, bpdp as dynamic_plugins_bp
from route_backend_agents import bpa as admin_agents_bp
from route_backend_agent_templates import bp_agent_templates
from route_backend_public_workspaces import *
from route_backend_public_documents import *
from route_backend_public_prompts import *
from route_backend_file_sync import register_route_backend_file_sync
from route_backend_workspace_identities import register_route_backend_workspace_identities
from route_backend_user_agreement import register_route_backend_user_agreement
from route_backend_conversation_export import register_route_backend_conversation_export
from route_backend_thoughts import register_route_backend_thoughts
from route_backend_speech import register_route_backend_speech
from route_backend_tts import register_route_backend_tts
from route_backend_collaboration import register_route_backend_collaboration
from route_backend_msgraph_pending_actions import register_route_backend_msgraph_pending_actions
from route_enhanced_citations import register_enhanced_citations_routes
from plugin_validation_endpoint import plugin_validation_bp
from route_openapi import register_openapi_routes
from route_migration import bp_migration
from route_plugin_logging import bpl as plugin_logging_bp
from functions_debug import debug_print

from opentelemetry.instrumentation.flask import FlaskInstrumentor

app = Flask(__name__, static_url_path='/static', static_folder='static')

disable_flask_instrumentation = os.environ.get("DISABLE_FLASK_INSTRUMENTATION", "0")
if not (disable_flask_instrumentation == "1" or disable_flask_instrumentation.lower() == "true"):
    FlaskInstrumentor().instrument_app(app)

app.config['EXECUTOR_TYPE'] = EXECUTOR_TYPE
app.config['EXECUTOR_MAX_WORKERS'] = EXECUTOR_MAX_WORKERS
executor = Executor()
executor.init_app(app)
app.config['SESSION_TYPE'] = SESSION_TYPE
app.config['VERSION'] = VERSION
app.config['SECRET_KEY'] = SECRET_KEY

# Ensure filesystem session directory (when used) points to a writable path inside container.
if SESSION_TYPE == 'filesystem':
    app.config['SESSION_FILE_DIR'] = globals().get('SESSION_FILE_DIR', os.environ.get('SESSION_FILE_DIR', '/app/flask_session'))
    try:
        os.makedirs(app.config['SESSION_FILE_DIR'], exist_ok=True)
    except Exception as e:
        print(f"WARNING: Unable to create session directory {app.config.get('SESSION_FILE_DIR')}: {e}")
        log_event(f"Unable to create session directory {app.config.get('SESSION_FILE_DIR')}: {e}", level=logging.ERROR)

Session(app)

app.register_blueprint(admin_plugins_bp)
app.register_blueprint(dynamic_plugins_bp)
app.register_blueprint(admin_agents_bp)
app.register_blueprint(bp_agent_templates)
app.register_blueprint(plugin_validation_bp)
app.register_blueprint(bp_migration)
app.register_blueprint(plugin_logging_bp)

# Register OpenAPI routes
register_openapi_routes(app)

# Register Enhanced Citations routes
register_enhanced_citations_routes(app)

# Register Speech routes
register_route_backend_speech(app)

# Register TTS routes
register_route_backend_tts(app)

# Register Swagger documentation routes
from swagger_wrapper import register_swagger_routes
register_swagger_routes(app)

from flask import g
from flask_session import Session
from redis import Redis
from functions_settings import get_settings
from functions_authentication import get_current_user_id
from functions_global_agents import ensure_default_global_agent_exists
from background_tasks import start_background_task_threads

from route_external_health import *

_app_init_lock = threading.Lock()
_app_initialized = False
_background_tasks_lock = threading.Lock()
_background_tasks_started = False


def is_running_under_gunicorn():
    """Return True when the current process is a Gunicorn worker."""
    server_software = os.environ.get('SERVER_SOFTWARE', '')
    return 'gunicorn' in server_software.lower() or bool(os.environ.get('GUNICORN_CMD_ARGS'))


def should_start_background_tasks():
    """Enable background loops unless the runtime explicitly disables them."""
    env_value = os.environ.get('SIMPLECHAT_RUN_BACKGROUND_TASKS')
    if env_value is not None:
        return env_value.strip().lower() not in ('0', 'false', 'no', 'off')

    return True

# =================== Session Configuration ===================
def configure_sessions(settings):
    """Configure session backend (Redis or filesystem) once.

    Falls back to filesystem if Redis settings are incomplete. Supports managed identity
    or key auth for Azure Redis. Uses SESSION_FILE_DIR already prepared in config/app init.
    """
    try:
        if settings.get('enable_redis_cache'):
            redis_url = settings.get('redis_url', '').strip()
            redis_auth_type = settings.get('redis_auth_type', 'key').strip().lower()

            if redis_url:
                redis_client = None
                try:
                    if redis_auth_type == 'managed_identity':
                        log_event("Redis enabled using Managed Identity", level=logging.INFO)
                        from config import get_redis_cache_infrastructure_endpoint
                        credential = DefaultAzureCredential()
                        redis_hostname = redis_url.split('.')[0]
                        cache_endpoint = get_redis_cache_infrastructure_endpoint(redis_hostname)
                        token = credential.get_token(cache_endpoint)
                        redis_client = Redis(
                            host=redis_url,
                            port=6380,
                            db=0,
                            password=token.token,
                            ssl=True,
                            socket_connect_timeout=5,
                            socket_timeout=5
                        )
                    elif redis_auth_type == 'key_vault':
                        log_event("Redis enabled using Key Vault Secret", level=logging.INFO)
                        from functions_keyvault import retrieve_secret_direct
                        redis_key_secret_name = settings.get('redis_key', '').strip()
                        redis_password = retrieve_secret_direct(redis_key_secret_name)
                        if redis_password:
                            redis_password = redis_password.strip()
                        redis_client = Redis(
                            host=redis_url,
                            port=6380,
                            db=0,
                            password=redis_password,
                            ssl=True,
                            socket_connect_timeout=5,
                            socket_timeout=5
                        )
                    else:
                        redis_key = settings.get('redis_key', '').strip()
                        log_event("Redis enabled using Access Key", level=logging.INFO)
                        redis_client = Redis(
                            host=redis_url,
                            port=6380,
                            db=0,
                            password=redis_key,
                            ssl=True,
                            socket_connect_timeout=5,
                            socket_timeout=5
                        )
                    
                    # Test the connection
                    redis_client.ping()
                    log_event("✅ Redis connection successful", level=logging.INFO)
                    app.config['SESSION_TYPE'] = 'redis'
                    app.config['SESSION_REDIS'] = redis_client
                    
                except Exception as redis_error:
                    print(f"⚠️  WARNING: Redis connection failed: {redis_error}")
                    print("Falling back to filesystem sessions for reliability")
                    app.config['SESSION_TYPE'] = 'filesystem'
            else:
                print("Redis enabled but URL missing; falling back to filesystem.")
                app.config['SESSION_TYPE'] = 'filesystem'
        else:
            app.config['SESSION_TYPE'] = 'filesystem'
    except Exception as e:
        print(f"⚠️  WARNING: Session configuration error; falling back to filesystem: {e}")
        log_event(f"Session configuration error; falling back to filesystem: {e}", level=logging.ERROR)
        app.config['SESSION_TYPE'] = 'filesystem'

    # Initialize session interface
    Session(app)

# =================== Helper Functions ===================
def start_background_tasks():
    """Start background loops once per process when enabled for the current runtime."""
    global _background_tasks_started

    with _background_tasks_lock:
        if _background_tasks_started:
            return

        if not should_start_background_tasks():
            print("Background tasks disabled for this web process.")
            _background_tasks_started = True
            return
        start_background_task_threads()
        _background_tasks_started = True


def initialize_application(force=False):
    """Initialize caches, clients, sessions, and optional background services once per process."""
    global _app_initialized

    with _app_init_lock:
        if _app_initialized and not force:
            return

        print("Initializing application...")
        settings = get_settings(use_cosmos=True)
        redis_hostname = settings.get('redis_url', '').strip().split('.')[0]
        app_settings_cache.configure_app_cache(
            settings,
            get_redis_cache_infrastructure_endpoint(redis_hostname)
        )
        app_settings_cache.update_settings_cache(settings)
        sanitized_settings = sanitize_settings_for_logging(settings)
        debug_print(f"DEBUG:Application settings: {sanitized_settings}")
        sanitized_settings_cache = sanitize_settings_for_logging(app_settings_cache.get_settings_cache())
        debug_print(f"DEBUG:App settings cache initialized: {'Using Redis cache:' + str(app_settings_cache.app_cache_is_using_redis)} {sanitized_settings_cache}")

        initialize_clients(settings)
        ensure_custom_logo_file_exists(app, settings)
        print("Setting up Application Insights logging...")
        setup_appinsights_logging(settings)
        logging.basicConfig(level=logging.DEBUG)
        ensure_default_global_agent_exists()

        start_background_tasks()

        enable_semantic_kernel = settings.get('enable_semantic_kernel', False)
        per_user_semantic_kernel = settings.get('per_user_semantic_kernel', False)
        if enable_semantic_kernel and not per_user_semantic_kernel:
            print("Semantic Kernel is enabled. Initializing...")
            initialize_semantic_kernel()

        configure_sessions(settings)
        _app_initialized = True
        print("Application initialized.")


@app.before_request
def ensure_application_initialized():
    initialize_application()


def get_idle_timeout_settings(settings=None):
    """
    Resolve and normalize idle timeout settings used for warning and logout enforcement.

    Args:
        settings (dict, optional): Settings dictionary to use. If None, uses request-scoped settings.

    Returns:
        tuple[int, int]: A tuple of (idle_timeout_minutes, idle_warning_minutes)
                         after parsing, fallback handling, and boundary normalization.

    Raises:
        None: Invalid values are handled via fallback defaults and warning logs.
    """
    if settings is None:
        settings = get_request_settings()

    timeout_raw = settings.get('idle_timeout_minutes', 30)
    warning_raw = settings.get('idle_warning_minutes', 28)

    try:
        timeout_minutes = int(timeout_raw)
    except (TypeError, ValueError):
        timeout_minutes = 30
        log_event(
            "Invalid idle timeout value detected; using default.",
            extra={
                "setting": "idle_timeout_minutes",
                "raw_value": str(timeout_raw),
                "fallback_value": 30
            },
            level=logging.WARNING
        )

    try:
        warning_minutes = int(warning_raw)
    except (TypeError, ValueError):
        warning_minutes = 28
        log_event(
            "Invalid idle warning value detected; using default.",
            extra={
                "setting": "idle_warning_minutes",
                "raw_value": str(warning_raw),
                "fallback_value": 28
            },
            level=logging.WARNING
        )

    normalized_timeout = max(10, timeout_minutes)
    if normalized_timeout != timeout_minutes:
        log_event(
            "Idle timeout value normalized to minimum allowed value.",
            extra={
                "setting": "idle_timeout_minutes",
                "original_value": timeout_minutes,
                "normalized_value": normalized_timeout
            },
            level=logging.WARNING
        )
    timeout_minutes = normalized_timeout

    normalized_warning = max(0, warning_minutes)
    if normalized_warning != warning_minutes:
        log_event(
            "Idle warning value normalized to minimum allowed value.",
            extra={
                "setting": "idle_warning_minutes",
                "original_value": warning_minutes,
                "normalized_value": normalized_warning
            },
            level=logging.WARNING
        )
    warning_minutes = normalized_warning

    if warning_minutes > timeout_minutes:
        previous_warning_minutes = warning_minutes
        warning_minutes = timeout_minutes
        log_event(
            "Idle warning value adjusted to not exceed idle timeout.",
            extra={
                "idle_timeout_minutes": timeout_minutes,
                "original_idle_warning_minutes": previous_warning_minutes,
                "adjusted_idle_warning_minutes": warning_minutes
            },
            level=logging.WARNING
        )

    return timeout_minutes, warning_minutes


def is_idle_timeout_enabled(settings=None):
    """
    Determine whether idle-timeout enforcement is enabled.

    Args:
        settings (dict, optional): Settings dictionary to use. If None, uses request-scoped settings.

    Returns:
        bool: True when idle-timeout enforcement should run; otherwise False.

    Raises:
        None: Unexpected values are coerced to boolean-compatible behavior.
    """
    if settings is None:
        settings = get_request_settings()

    enabled_raw = settings.get('enable_idle_timeout', False)

    if isinstance(enabled_raw, str):
        return enabled_raw.strip().lower() in ('1', 'true', 'yes', 'on')

    return bool(enabled_raw)


settings_source_counters = {}
settings_source_counters_lock = threading.Lock()
settings_source_last_observed = None
settings_source_last_non_cache_log_epoch = 0
settings_source_non_cache_log_interval_seconds = 60


def record_request_settings_source(source):
    """
    Record and log the source used to resolve request settings.

    Args:
        source (str): Settings source label (for example: cache, cosmos_fallback, cosmos_forced).

    Returns:
        None: Updates in-memory counters and request context diagnostics.

    Raises:
        None: Counter updates and diagnostics are handled internally.
    """
    normalized_source = source or 'unknown'
    now_epoch = int(time.time())

    global settings_source_last_observed
    global settings_source_last_non_cache_log_epoch

    with settings_source_counters_lock:
        settings_source_counters[normalized_source] = settings_source_counters.get(normalized_source, 0) + 1
        cache_hits = settings_source_counters.get('cache', 0)
        cosmos_fallback_hits = settings_source_counters.get('cosmos_fallback', 0)
        cosmos_forced_hits = settings_source_counters.get('cosmos_forced', 0)
        unknown_hits = settings_source_counters.get('unknown', 0)

        previous_source = settings_source_last_observed
        source_changed = normalized_source != previous_source
        settings_source_last_observed = normalized_source

        non_cache_log_window_elapsed = (
            now_epoch - settings_source_last_non_cache_log_epoch
        ) >= settings_source_non_cache_log_interval_seconds

        should_log_non_cache_info = (
            normalized_source != 'cache'
            and (source_changed or non_cache_log_window_elapsed)
        )

        if should_log_non_cache_info:
            settings_source_last_non_cache_log_epoch = now_epoch

    g.request_settings_source = normalized_source
    # debug_print(
    #     f"[SETTINGS SOURCE] path={request.path} source={normalized_source}",
    #     category="SETTINGS",
    #     cache_hits=cache_hits,
    #     cosmos_fallback_hits=cosmos_fallback_hits,
    #     cosmos_forced_hits=cosmos_forced_hits,
    #     unknown_hits=unknown_hits
    # )

    if should_log_non_cache_info:
        log_event(
            "Request settings source is non-cache.",
            extra={
                "path": request.path,
                "settings_source": normalized_source,
                "source_changed": source_changed,
                "non_cache_log_window_elapsed": non_cache_log_window_elapsed,
                "cache_hits": cache_hits,
                "cosmos_fallback_hits": cosmos_fallback_hits,
                "cosmos_forced_hits": cosmos_forced_hits,
                "unknown_hits": unknown_hits
            },
            level=logging.INFO
        )


def get_request_settings():
    """
    Get request-scoped settings, resolving and caching them when needed.

    Args:
        None

    Returns:
        dict: Request settings dictionary cached on Flask `g` for the current request.

    Raises:
        None: Unexpected resolver response shapes are logged and handled with safe fallbacks.
    """
    request_settings = getattr(g, 'request_settings', None)
    if request_settings is None:
        settings_result = get_settings(include_source=True)
        if isinstance(settings_result, tuple) and len(settings_result) == 2:
            request_settings, settings_source = settings_result
        else:
            request_settings = settings_result
            settings_source = 'unknown'
            log_event(
                "Unexpected settings response shape in get_request_settings.",
                extra={
                    "path": request.path,
                    "response_type": type(settings_result).__name__
                },
                level=logging.WARNING
            )

        request_settings = request_settings or {}
        g.request_settings = request_settings
        record_request_settings_source(settings_source)
    return request_settings

@app.context_processor
def inject_settings():
    settings = get_request_settings()
    public_settings = sanitize_settings_for_user(settings)
    idle_timeout_enabled = is_idle_timeout_enabled(settings)
    idle_timeout_minutes, idle_warning_minutes = get_idle_timeout_settings(settings)
    # Inject per-user settings if logged in
    user_settings = {}
    try:
        user_id = get_current_user_id()
        if user_id:
            from functions_settings import get_user_settings
            user_settings = get_user_settings(user_id) or {}
    except Exception as e:
        print(f"Error injecting user settings: {e}")
        log_event(f"Error injecting user settings: {e}", level=logging.ERROR)
        user_settings = {}
    return dict(
        app_settings=public_settings,
        user_settings=user_settings,
        idle_timeout_enabled=idle_timeout_enabled,
        idle_timeout_minutes=idle_timeout_minutes,
        idle_warning_minutes=idle_warning_minutes
    )

@app.template_filter('to_datetime')
def to_datetime_filter(value):
    return datetime.fromisoformat(value)

@app.template_filter('format_datetime')
def format_datetime_filter(value):
    return value.strftime('%Y-%m-%d %H:%M')

# =================== SK Hot Reload Handler ===================
@app.before_request
def reload_kernel_if_needed():
    if getattr(builtins, "kernel_reload_needed", False):
        debug_print(f"[SK Loader] Hot reload: re-initializing Semantic Kernel and agents due to settings change.")
        """Commneted out because hot reload is not fully supported yet.
        log_event(
            "[SK Loader] Hot reload: re-initializing Semantic Kernel and agents due to settings change.",
            level=logging.INFO
        )
        initialize_semantic_kernel()
        """
        setattr(builtins, "kernel_reload_needed", False)


def _is_idle_timeout_exempt(path):
    """
    Check whether a request path is exempt from idle-timeout processing.

    Args:
        path (str): Request path to evaluate.

    Returns:
        bool: True if the path is exempt from idle-timeout checks; otherwise False.

    Raises:
        None
    """
    if path in IDLE_TIMEOUT_EXEMPT_PATHS:
        return True
    return any(path.startswith(prefix) for prefix in IDLE_TIMEOUT_EXEMPT_PREFIXES)


def maybe_log_authenticated_browser_request():
    """Record throttled login activity for authenticated browser page requests."""
    if request.method != 'GET' or request.path.startswith('/api/'):
        return

    user_id = session.get('user', {}).get('oid') or session.get('user', {}).get('sub')
    if not user_id:
        return

    maybe_log_authenticated_request_login(
        user_id=user_id,
        session_state=session,
        request_path=request.path,
        request_method=request.method
    )

@app.before_request
def enforce_idle_session_timeout():
    """
    Enforce server-side idle session timeout for authenticated requests.

    Args:
        None

    Returns:
        Response | None: A redirect/401 response when timeout is exceeded; otherwise None.

    Raises:
        None: Runtime issues in timeout evaluation are logged and request processing continues safely.
    """
    if 'user' not in session:
        return None

    if request.method == 'OPTIONS' or _is_idle_timeout_exempt(request.path):
        return None

    now_epoch = int(time.time())
    request_settings = get_request_settings()
    if not is_idle_timeout_enabled(request_settings):
        disabled_refresh_interval_seconds = 60
        last_activity_epoch = session.get('last_activity_epoch')
        should_refresh_last_activity = False

        if last_activity_epoch is None:
            should_refresh_last_activity = True
        else:
            try:
                parsed_last_activity_epoch = int(float(last_activity_epoch))
                if (
                    parsed_last_activity_epoch > now_epoch
                    or (now_epoch - parsed_last_activity_epoch) >= disabled_refresh_interval_seconds
                ):
                    should_refresh_last_activity = True
            except (TypeError, ValueError):
                should_refresh_last_activity = True

        if should_refresh_last_activity:
            session['last_activity_epoch'] = now_epoch
            session.modified = True
        maybe_log_authenticated_browser_request()
        return None

    idle_timeout_minutes, _ = get_idle_timeout_settings(request_settings)
    last_activity_epoch = session.get('last_activity_epoch')
    has_valid_last_activity_epoch = False
    max_allowed_future_skew_seconds = 60

    if last_activity_epoch is not None:
        try:
            parsed_last_activity_epoch = int(float(last_activity_epoch))
            if parsed_last_activity_epoch <= (now_epoch + max_allowed_future_skew_seconds):
                has_valid_last_activity_epoch = True
            else:
                log_event(
                    "Idle timeout last_activity_epoch is in the future; resetting timestamp.",
                    extra={
                        "path": request.path,
                        "parsed_last_activity_epoch": parsed_last_activity_epoch,
                        "now_epoch": now_epoch,
                        "max_allowed_future_skew_seconds": max_allowed_future_skew_seconds
                    },
                    level=logging.WARNING
                )
            idle_seconds = now_epoch - parsed_last_activity_epoch
            if idle_seconds >= (idle_timeout_minutes * 60):
                user_id = session.get('user', {}).get('oid') or session.get('user', {}).get('sub')
                session.clear()

                log_event(
                    f"Session expired due to {idle_timeout_minutes} minute inactivity timeout for user {user_id or 'unknown'}.",
                    level=logging.INFO
                )

                if request.path.startswith('/api/'):
                    return jsonify({
                        'error': 'Session expired',
                        'message': 'Your session expired due to inactivity. Please sign in again.',
                        'requires_reauth': True
                    }), 401

                return redirect(url_for('local_logout'))
        except Exception as e:
            log_event(f"Idle timeout evaluation failed: {e}", level=logging.WARNING)

    if request.path.startswith('/api/'):
        if not has_valid_last_activity_epoch:
            session['last_activity_epoch'] = now_epoch
            session.modified = True
        return None

    session['last_activity_epoch'] = now_epoch
    session.modified = True
    maybe_log_authenticated_browser_request()
    return None

@app.after_request
def add_security_headers(response):
    """
    Add comprehensive security headers to all responses to protect against
    various web vulnerabilities including MIME sniffing attacks.
    """
    from config import SECURITY_HEADERS, ENABLE_STRICT_TRANSPORT_SECURITY, HSTS_MAX_AGE
    
    # Apply all configured security headers
    for header_name, header_value in SECURITY_HEADERS.items():
        response.headers[header_name] = header_value
    
    # Add HSTS header only if HTTPS is enabled and configured
    if ENABLE_STRICT_TRANSPORT_SECURITY and request.is_secure:
        response.headers['Strict-Transport-Security'] = f'max-age={HSTS_MAX_AGE}; includeSubDomains; preload'
    
    # Ensure X-Content-Type-Options is always present for specific content types
    # This provides extra protection against MIME sniffing attacks
    if response.content_type and any(ct in response.content_type.lower() for ct in ['text/', 'application/json', 'application/javascript', 'application/octet-stream']):
        response.headers['X-Content-Type-Options'] = 'nosniff'
    
    return response

# Register a custom Jinja filter for Markdown
def markdown_filter(text):
    if not text:
        text = ""

    # Convert Markdown to HTML
    html = markdown2.markdown(text)

    # Add target="_blank" to all <a> links
    html = re.sub(r'(<a\s+href=["\'](https?://.*?)["\'])', r'\1 target="_blank" rel="noopener noreferrer"', html)

    return Markup(html)

# Add the filter to the Jinja environment
app.jinja_env.filters['markdown'] = markdown_filter

# Register a custom Jinja filter for nl2br (newline to <br>)
def nl2br_filter(value):
    """Escape HTML then convert newline characters to <br> tags."""
    from markupsafe import escape, Markup
    if not value:
        return Markup('')
    return Markup(str(escape(value)).replace('\n', '<br>\n'))

app.jinja_env.filters['nl2br'] = nl2br_filter

# =================== Default Routes =====================
@app.route('/')
@swagger_route(security=get_auth_security())
def index():
    settings = get_settings()
    public_settings = sanitize_settings_for_user(settings)

    # Ensure landing_page_text is always a valid string
    landing_text = settings.get("landing_page_text", "Click the button below to start chatting with the AI assistant. You agree to our [acceptable user policy by using this service](acceptable_use_policy.html).")

    # Convert Markdown to HTML safely
    landing_html = markdown_filter(landing_text)

    return render_template('index.html', app_settings=public_settings, landing_html=landing_html)

@app.route('/robots933456.txt')
@swagger_route(security=get_auth_security())
def robots():
    return send_from_directory('static', 'robots.txt')

@app.route('/favicon.ico')
@swagger_route(security=get_auth_security())
def favicon():
    return send_from_directory('static', 'favicon.ico')

@app.route('/static/js/<path:filename>')
@swagger_route(security=get_auth_security())
def serve_js_modules(filename):
    """Serve JavaScript modules with correct MIME type."""
    from flask import send_from_directory, Response
    if filename.endswith('.mjs'):
        # Serve .mjs files with correct MIME type for ES modules
        response = send_from_directory('static/js', filename)
        response.headers['Content-Type'] = 'application/javascript'
        return response
    else:
        return send_from_directory('static/js', filename)

@app.route('/acceptable_use_policy.html')
@swagger_route(security=get_auth_security())
def acceptable_use_policy():
    return render_template('acceptable_use_policy.html')

@app.route('/api/session/heartbeat', methods=['POST'])
@swagger_route(security=get_auth_security())
@login_required
def session_heartbeat():
    """
    Refresh the authenticated session activity timestamp used by idle-timeout enforcement.

    Args:
        None

    Returns:
        tuple[Response, int]: JSON response containing refresh confirmation and timeout metadata.

    Raises:
        None
    """
    session['last_activity_epoch'] = int(time.time())
    session.modified = True
    idle_timeout_minutes, _ = get_idle_timeout_settings(get_request_settings())
    return jsonify({
        'message': 'Session refreshed',
        'idle_timeout_minutes': idle_timeout_minutes
    }), 200

@app.route('/api/semantic-kernel/plugins')
@swagger_route(security=get_auth_security())
def list_semantic_kernel_plugins():
    """Test endpoint: List loaded Semantic Kernel plugins and their functions."""
    global kernel
    if not kernel:
        return {"error": "Kernel not initialized"}, 500
    plugins = {}
    for plugin_name, plugin in kernel.plugins.items():
        plugins[plugin_name] = [func.name for func in plugin.functions.values()]
    return {"plugins": plugins}


# =================== Front End Routes ===================
# ------------------- User Authentication Routes ---------
register_route_frontend_authentication(app)

# ------------------- User Profile Routes ----------------
register_route_frontend_profile(app)

# ------------------- Admin Settings Routes --------------
register_route_frontend_admin_settings(app)

# ------------------- Control Center Routes --------------
register_route_frontend_control_center(app)

# ------------------- Chats Routes -----------------------
register_route_frontend_chats(app)

# ------------------- Conversations Routes ---------------
register_route_frontend_conversations(app)

# ------------------- Documents Routes -------------------
register_route_frontend_workspace(app)

# ------------------- Groups Routes ----------------------
register_route_frontend_groups(app)

# ------------------- Group Documents Routes -------------
register_route_frontend_group_workspaces(app)
register_route_frontend_public_workspaces(app)

# ------------------- Safety Routes ----------------------
register_route_frontend_safety(app)

# ------------------- Feedback Routes -------------------
register_route_frontend_feedback(app)

# ------------------- Support Routes --------------------
register_route_frontend_support(app)

# ------------------- Notifications Routes --------------
register_route_frontend_notifications(app)

# ------------------- API Chat Routes --------------------
register_route_backend_chats(app)

# ------------------- API Search Routes ------------------
register_route_backend_search(app)

# ------------------- API Conversation Routes ------------
register_route_backend_conversations(app)

# ------------------- API Collaboration Routes -----------
register_route_backend_collaboration(app)

# ------------------- API MS Graph Pending Action Routes -
register_route_backend_msgraph_pending_actions(app)

# ------------------- API Documents Routes ---------------
register_route_backend_documents(app)

# ------------------- API Groups Routes ------------------
register_route_backend_groups(app)

# ------------------- API User Routes --------------------
register_route_backend_users(app)

# ------------------- API Group Documents Routes ---------
register_route_backend_group_documents(app)

# ------------------- API Model Routes -------------------
register_route_backend_models(app)

# ------------------- API Workflow Routes ----------------
register_route_backend_workflows(app)

# ------------------- API Safety Logs Routes -------------
register_route_backend_safety(app)

# ------------------- API Feedback Routes ---------------
register_route_backend_feedback(app)

# ------------------- API Settings Routes ---------------
register_route_backend_settings(app)

# ------------------- API Prompts Routes ----------------
register_route_backend_prompts(app)

# ------------------- API Group Prompts Routes ----------
register_route_backend_group_prompts(app)

# ------------------- API Control Center Routes ---------
register_route_backend_control_center(app)

# ------------------- API Notifications Routes ----------
register_route_backend_notifications(app)

# ------------------- API Retention Policy Routes --------
register_route_backend_retention_policy(app)

# ------------------- API Public Workspaces Routes -------
register_route_backend_public_workspaces(app)

# ------------------- API Conversation Export Routes -----
register_route_backend_conversation_export(app)

# ------------------- API Public Documents Routes --------
register_route_backend_public_documents(app)

# ------------------- API Public Prompts Routes ----------
register_route_backend_public_prompts(app)

# ------------------- API File Sync Routes ---------------
register_route_backend_file_sync(app)

# ------------------- API Workspace Identity Routes ------
register_route_backend_workspace_identities(app)

# ------------------- API User Agreement Routes ----------
register_route_backend_user_agreement(app)

# ------------------- API Thoughts Routes ----------------
register_route_backend_thoughts(app)

# ------------------- External Health Routes ----------
register_route_external_health(app)
register_no_auth_health(app)

if __name__ == '__main__':
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    use_gunicorn = os.environ.get("SIMPLECHAT_USE_GUNICORN", "0").strip().lower() in ('1', 'true', 'yes', 'on')

    if use_gunicorn and not debug_mode:
        gunicorn_config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'gunicorn.conf.py')
        print(f"Starting Gunicorn using {gunicorn_config_path}")
        os.execvp(sys.executable, [sys.executable, '-m', 'gunicorn', '-c', gunicorn_config_path, 'app:app'])

    if use_gunicorn and debug_mode:
        print("⚠️  WARNING: Both Gunicorn and Flask debug mode are enabled, which is not supported. Please disable one of them, app will not run until resolved.")
        log_event("WARNING: Running with both Gunicorn and Flask debug mode is not supported. Please disable one of them, app will not run until resolved.", level=logging.WARNING)
        exit(1)

    initialize_application(force=True)

    if debug_mode:
        # Local development with HTTPS
        # use_reloader=False prevents too_many_retries errors with static files
        # Disable excessive logging for static file requests in development
        werkzeug_logger = logging.getLogger('werkzeug')
        werkzeug_logger.setLevel(logging.ERROR)
        app.run(host="0.0.0.0", port=5000, debug=True, ssl_context='adhoc', threaded=True, use_reloader=False)
    else:
        # Production
        port = int(os.environ.get("PORT", 5000))
        app.run(host="0.0.0.0", port=port, debug=False)
